﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class Circle : Shape
    {
        public double _radio;


        public Circle(double alto, double ancho) : base(alto, ancho)
        {

            Ancho = ancho;
            Alto = alto;
        }
        public override double CalculateSurface()
        {
            return Math.PI * Math.Pow(_radio, 2);
        }
    }

}
