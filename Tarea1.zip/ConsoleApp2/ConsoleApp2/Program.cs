﻿
using System.Drawing;

namespace ConsoleApp2 { 
class Proyect
{
    static void Main(String[] args)
    {
        Shape triangulo = new Triangle(5.2, 7.6);
        Shape rectangulo = new Rectangle(6.9, 3.1);
        Shape circulo = new Circle(8,3);
        Shape[] shapesDiferentes = new Shape[3];

        shapesDiferentes[0] = triangulo;
        shapesDiferentes[1] = rectangulo;
        shapesDiferentes[2] = circulo;

        double[] shapesAreas = new double[3];

        for (int i = 0; i < 3; i++)
        {
            shapesAreas[i] = shapesDiferentes[i].CalculateSurface();
            Console.WriteLine("Se añadio el valor: " + i);
        }

        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine("El area de la figura " + i + " es de: " + shapesAreas[i]);
        }
    }
}




public abstract class Shape
{
    public double Ancho;
    public double Alto;
    public Shape(double ancho, double alto)
    {
        this.Ancho = ancho;
        this.Alto = alto;
    }

    public abstract double CalculateSurface();

}
  
}
